# apisec-theme-pack (v2.0.0)

> **Portable Design System**: Fusion of the **apisec|con 2026 Technical-Editorial Swiss Grid** and **HUD React 18 Tactical Telemetry Architecture**.

## 🚀 Quick Migration to Any New Project

### 1. Copy Folder
Copy this entire directory into your new project's source tree:
```bash
cp -r apisec-theme-pack /path/to/new-project/src/theme
```

### 2. Import CSS in Entry File
In your main entry file (`main.tsx`, `index.tsx`, or Next.js `app/layout.tsx`):
```typescript
import './theme/theme.css';
import { ThemeProvider } from './theme/ThemeProvider';

export default function RootLayout({ children }) {
  return (
    <ThemeProvider defaultMode="dark">
      {children}
    </ThemeProvider>
  );
}
```

### 3. Use Typed React Primitives & Validators
```typescript
import {
  AuHudCard,
  AuTabs,
  AuButton,
  AuBadge,
  AuModal,
  AuSelect,
  AuValidatedInput,
  AuCheckbox,
  AuTokenChip,
  AuCodeViewer,
  validateTagKey,
  validateTagAllowedValues,
  validateNamingPattern
} from './theme';

export function Dashboard() {
  return (
    <AuHudCard
      kicker="AZURE GOVERNANCE"
      title="Landing Zone Compliance"
      meta="4 Management Groups · 42 Policies Enforced"
      action={<AuButton variant="primary" size="sm">Export IaC</AuButton>}
    >
      <AuSelect
        label="Environment Tier"
        value="prod"
        onChange={(val) => console.log(val)}
        options={['prod', 'nonprod', 'dev', 'stage']}
      />
    </AuHudCard>
  );
}
```



## 🎨 Design Tokens & Visual Architecture
- **Palette**: Deep Petrol canvas (`#06252D`), surface (`#12323E`), elevated (`#16404C`), and tactical accents (`#48A9A6` teal, `#64BA6D` mint, `#249D79` HUD emerald).
- **HUD Reticle Cards**: Every `<AuHudCard>` features 4-corner hairline reticles (`.au-card-arrow-tl/tr/bl/br`) with interactive hover glow.
- **Background Texture**: 22px fixed radial dot-grid canvas.
- **Typography**: Spectral (Editorial Serif Headlines) + IBM Plex Sans (Body) + IBM Plex Mono (Code & Metadata).
