# @0ccupi3r/tactical-ui (v2.0.0)

> **Portable Design System**: Tactical HUD & Editorial Swiss Grid React 18/19 UI Architecture.

---

## 🚀 Quick Migration to Any Project

### Option A: Direct Copy / Unzip
Copy or unzip this folder into your new project's source tree:
```bash
# If unzipping archive:
unzip tactical-ui.zip -d ./my-project/src/theme

# If copying directory:
cp -r tactical-ui /path/to/my-project/src/theme
```

### Option B: Local npm Install
You can install this folder directly as a local package:
```bash
npm install /path/to/tactical-ui
```
Or install from the packaged tarball:
```bash
npm install ./0ccupi3r-tactical-ui-2.0.0.tgz
```

---

## 📦 Setup in 3 Simple Steps

### 1. Install Peer Dependencies
```bash
npm install lucide-react
```
*(Requires React 18+ or React 19)*

### 2. Import CSS in App Root
In your main entry file (`main.tsx`, `index.tsx`, or Next.js `app/layout.tsx`):
```typescript
import './theme/theme.css';
import { ThemeProvider } from './theme';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider defaultMode="dark">
      {children}
    </ThemeProvider>
  );
}
```

### 3. Use Typed React Primitives & Validators
```typescript
import React, { useState } from 'react';
import {
  AuHudCard,
  AuTabs,
  AuButton,
  AuBadge,
  AuModal,
  AuSelect,
  AuValidatedInput,
  AuCheckbox,
  AuTokenChip,
  AuCodeViewer,
  validateTagKey,
  validateNamingPattern
} from './theme';

export function Dashboard() {
  const [env, setEnv] = useState('prod');

  return (
    <AuHudCard
      kicker="TACTICAL GOVERNANCE"
      title="Platform Operations Telemetry"
      meta="4 Management Groups · 42 Policies Enforced"
      action={<AuButton variant="primary" size="sm">Export Artifacts</AuButton>}
    >
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <AuSelect
          label="Environment Tier"
          value={env}
          onChange={setEnv}
          options={[
            { value: 'prod', label: 'Production (Strict)' },
            { value: 'nonprod', label: 'Non-Production' },
            { value: 'dev', label: 'Development' }
          ]}
        />
        
        <AuValidatedInput
          label="Resource Name"
          defaultValue="corp-hub-vnet"
          validator={(val) => validateNamingPattern(val)}
        />
      </div>
    </AuHudCard>
  );
}
```

---

## 🎨 Visual Identity & Architecture
- **Palette**: Deep Petrol canvas (`#06252D`), surface (`#12323E`), elevated (`#16404C`), tactical teal (`#48A9A6`), mint (`#64BA6D`), and HUD emerald (`#249D79`).
- **HUD Reticle Cards**: Every `<AuHudCard>` features 4-corner hairline reticles with interactive hover glow.
- **Background Texture**: 22px fixed radial dot-grid canvas.
- **Typography**: Spectral (Editorial Serif Headlines) + IBM Plex Sans (Body) + IBM Plex Mono (Code & Metadata).
- **Tailwind Preset**: Integrate directly with Tailwind CSS via `tailwind.preset.js`.
